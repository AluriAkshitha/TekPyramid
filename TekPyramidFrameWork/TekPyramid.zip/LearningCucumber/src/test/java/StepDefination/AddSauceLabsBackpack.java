package StepDefination;

import java.sql.DriverManager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;



public class AddSauceLabsBackpack {
	
	public static WebDriver driver;
//	@Before
//	public void setUp()
//	{
//		WebDriverManager.chromedriver().setup();
//		driver=new ChromeDriver();
//		
//		
//	}
	
	
	@And("Add Sauce Labs Backpack To the cart")
	public void add_sauce_labs_backpack_to_the_cart()  {
		
		WebElement AddToCart = driver.findElement(By.xpath("//div[@class='inventory_list']//div[1]//div[3]//button[1]"));
		AddToCart.click();
		}
	
	@And("Click On Logut")
	public void click_on_logut() {
		WebElement menu = driver.findElement(By.xpath("//button[text()='Open Menu']"));
		menu.click();
		
	    WebElement Logout = driver.findElement(By.xpath("//a[@id='logout_sidebar_link']"));
	    Logout.click();
	    }
	
	@And("Quiting the Browser")
	public void quiting_the_browser()
	{
		driver.quit();
	}
	
	}

