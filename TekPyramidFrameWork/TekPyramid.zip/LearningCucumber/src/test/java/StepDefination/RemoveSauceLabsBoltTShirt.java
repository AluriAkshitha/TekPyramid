package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.*;

public class RemoveSauceLabsBoltTShirt {
	
	WebDriver driver;
	
	@Then("Remove Sauce Labs Bolt T-Shirt From the cart")
	public void remove_sauce_labs_bolt_t_shirt_from_the_cart() {
		
		driver.findElement(By.cssSelector("path[fill='currentColor']")).click();
		driver.findElement(By.xpath("(//button[text()='REMOVE'])[3]")).click();
		driver.findElement(By.linkText("Continue Shopping")).click();
	    
	}

	@And("Doing the Logout")
	public void doing_the_logout() {
		
		driver.findElement(By.xpath("//button[text()='Open Menu']")).click();
		driver.findElement(By.xpath("//a[@id='logout_sidebar_link']")).click();
	   
	}

	@And("Terminate  the Entire Browser")
	public void terminate_the_entire_browser() {
		
		driver.quit();
	    
	}




}
