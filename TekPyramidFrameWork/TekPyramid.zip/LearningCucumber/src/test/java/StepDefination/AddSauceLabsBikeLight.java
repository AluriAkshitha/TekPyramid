package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.*;

public class AddSauceLabsBikeLight {
	WebDriver driver;
	
	@Then("Add Sauce Labs Bike Light To the cart")
	public void add_sauce_labs_bike_light_to_the_cart()
	{
		driver.findElement(By.xpath("(//button[text()='ADD TO CART'])[2]")).click();
	}
	
	
	@And("Clicking On Logut")
	public void clicking_on_logut() {
		driver.findElement(By.xpath("//button[normalize-space()='Open Menu']")).click();
		driver.findElement(By.xpath("(//a[normalize-space()='Logout'])[1]")).click();
	    
	}

	@And("Quit the browser")
	public void quit_the_browser() {
		
		driver.quit();
	    
	}

	
	




}
