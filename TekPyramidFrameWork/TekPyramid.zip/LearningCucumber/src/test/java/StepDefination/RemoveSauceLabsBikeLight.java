package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.*;

public class RemoveSauceLabsBikeLight {
	WebDriver driver;
	
	@Then("Remove Sauce Labs Bike Light From the cart")
	public void remove_sauce_labs_bike_light_from_the_cart() {
		
		driver.findElement(By.cssSelector("path[fill='currentColor']")).click();
		driver.findElement(By.xpath("(//button[text()='REMOVE'])[2]")).click();
		driver.findElement(By.linkText("Continue Shopping")).click();
	    
	}

	@And("Doing Logout")
	public void doing_logout() {
		
		driver.findElement(By.xpath("//button[text()='Open Menu']")).click();
		driver.findElement(By.xpath("//a[@id='logout_sidebar_link']")).click();
	   
	}

	@And("Terminate the Browser")
	public void terminate_the_browser() {
		
		driver.quit();
	   	}



}
