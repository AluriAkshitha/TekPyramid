package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.*;

public class AddSaucelLabsBoltTShirt {
	WebDriver driver;
	
	@Then("Add Sauce Labs Bolt T-Shirt To the cart")
	public void add_sauce_labs_bolt_t_shirt_to_the_cart() {
		driver.findElement(By.xpath("(//button[text()='ADD TO CART'])[3]")).click();
	    
	}

	@And("Clicking On Loggingout")
	public void clicking_on_loggingout() {
	    
		driver.findElement(By.xpath("//button[normalize-space()='Open Menu']")).click();
		driver.findElement(By.xpath("(//a[normalize-space()='Logout'])[1]")).click();
	    	
	}

	@And("Quting the entire browser")
	public void quting_the_entire_browser() {
	    
		driver.quit();
	}




}
