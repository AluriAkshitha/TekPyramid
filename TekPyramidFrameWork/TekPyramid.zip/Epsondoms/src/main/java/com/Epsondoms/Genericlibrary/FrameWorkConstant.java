package com.Epsondoms.Genericlibrary;

public interface FrameWorkConstant {
	public static String propertypath="./src/test/resources/TestData/commondata.properties";
	public static String excelpath="./src/test/resources/TestData/EmpDetails.xlsx";
	public static long duration=101;

}
