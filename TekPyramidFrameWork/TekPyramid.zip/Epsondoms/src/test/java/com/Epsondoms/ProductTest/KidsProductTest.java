package com.Epsondoms.ProductTest;

import org.testng.annotations.Test;

public class KidsProductTest {
	@Test
	public void addProduct()
	{
	System.out.println("Add Product Successfully-KIDS-");	
	}
	
	@Test
	public void updateProduct()
	{
		System.out.println("Update the Product Successfully-KIDS-");
	}
	@Test
	public void removeProduct()
	{
		System.out.println("Remove Product Successfully-KIDS-");
	}

}
