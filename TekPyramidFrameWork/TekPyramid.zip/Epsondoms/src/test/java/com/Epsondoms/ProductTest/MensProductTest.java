package com.Epsondoms.ProductTest;

import org.testng.annotations.Test;

public class MensProductTest {
	@Test
	public void addProduct()
	{
	System.out.println("Add Product Successfully-MENS-");	
	}
	
	@Test
	public void updateProduct()
	{
		System.out.println("Update the Product Successfully-MENS-");
	}
	@Test
	public void removeProduct()
	{
		System.out.println("Remove Product Successfully-MENS-");
	}


}



