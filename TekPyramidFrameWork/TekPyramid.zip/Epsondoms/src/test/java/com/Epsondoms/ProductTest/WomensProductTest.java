package com.Epsondoms.ProductTest;

import org.testng.annotations.Test;

public class WomensProductTest {
	@Test
	public void addProduct()
	{
	System.out.println("Add Product Successfully-WOMENS-");	
	}
	
	@Test
	public void updateProduct()
	{
		System.out.println("Update the Product Successfully-WOMENS-");
	}
	@Test
	public void removeProduct()
	{
		System.out.println("Remove Product Successfully-WOMENS-");
	}

}
