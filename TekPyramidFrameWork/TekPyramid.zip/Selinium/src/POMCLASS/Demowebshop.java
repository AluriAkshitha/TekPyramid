package POMCLASS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Demowebshop {


		@FindBy(id="gender-female")
		private WebElement Female;
		
		@FindBy(id="FirstName")
		private WebElement FirstName;
		
		@FindBy(id="LastName")
		private WebElement LastName ;
		
		@FindBy(id="Email")
		private WebElement Email ;
		
		@FindBy(id="Password")
		private WebElement Password ;
		
		@FindBy(id="ConfirmPassword")
		private WebElement ConfirmPassword ;
		
		@FindBy(id="register-button")
		private WebElement Register;
		
		
		

		public Demowebshop(WebDriver driver)
		{
			PageFactory.initElements(driver,this);
		}
		
		public void getgenderFemale()
		{
			Female.click();
		}
		public void getFirstName(String data)
		{
	     FirstName.sendKeys(data);
		}
		public void getLastName(String data)
		{
			LastName.sendKeys(data);
		}
		public void getEmail(String data)
		{
			Email.sendKeys(data);
		}
		public void getPassword(String data)
		{
			Password.sendKeys(data);
		}
		public void getConfirmpassword(String data)
		{
			ConfirmPassword.sendKeys(data);
		}
		
		public void getRegister()
		{
			Register.click();
		}
		

	}


