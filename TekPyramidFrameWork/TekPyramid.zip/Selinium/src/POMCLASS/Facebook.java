package POMCLASS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Facebook {
	WebDriver driver;
	@FindBy(xpath="(//a[contains(text(),'Create')])[1]")
	private WebElement Create;
	
	@FindBy(name="firstname")
	private WebElement FirstName;
	
	@FindBy(name="lastname")
	private WebElement LastName;
	
	
	
	@FindBy(xpath="//input[contains(@name,'reg_email__' )]")
	private WebElement Email;
	
	@FindBy(name="reg_email_confirmation__")
	 WebElement ReEnter;
	
	@FindBy(xpath="(//input[@id='password_step_input'])[1]")
	private WebElement Password;
	
	
	
	@FindBy(id="day")
	private WebElement Day;
	
	@FindBy(id="month")
	private WebElement Month;
	
	@FindBy(id="year")
	private WebElement Year;
	
	@FindBy(name="sex")
	private WebElement Gender;
	
	@FindBy(name="websubmit")
	private WebElement Submit;
	
	
	public Facebook(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void getCreate()
	{
		Create.click();
	}
	
	public void getFirstName(String data)
	{
		FirstName.sendKeys(data);
	}
	
	public void getLastName(String data)
	{
		LastName.sendKeys(data);
	}
	
	public void getEmail(String data)
	{
		Email.sendKeys(data);
	}
	public void setReEnterEmail(String data)
	{
		ReEnter.sendKeys(data);
	}
	
	public void getPassword(String data)
	{
		Password.sendKeys(data);
	}
	
	public void getDate(int data)
	{
		Select s1=new Select(Day);
		s1.selectByIndex(data);
	}
	public void getMonth(String data)
	{
		Select s2=new Select(Month);
		s2.selectByVisibleText(data);
	}
	public void getyear(String data)
	{
		Select s3=new Select(Year);
		s3.selectByValue(data);
	}
	public void getGender()
	{
		Gender.click();
	}
	public void getSubmit()
	{
		Submit.click();
	}

	
	}

