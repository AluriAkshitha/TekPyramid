package POMCLASS;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoQspiders1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://demoapps.qspiders.com/ui/login?scenario=1");
		DemoQspiders dq=new DemoQspiders(driver);
		dq.getemail	("aluriakshitha8855@gmail.com");
		Thread.sleep(2000);
		dq.getpassword("Suhan1122@");
		Thread.sleep(2000);
		dq.getlogin();

	}

}
