package POMCLASS;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class DemoQspiders {
	@FindBy(id="email")
	private WebElement email;
	
	@FindBy(id="password")
	private WebElement password;
	
	@FindBy(xpath="//button[text()='Login']")
	private WebElement login;
	
	public DemoQspiders(WebDriver driver)
	{
		PageFactory.initElements(driver,this);
	}
	
	public void getemail(String data)
	{
      email.sendKeys(data);
	}
	public void getpassword(String data)
	{
		password.sendKeys(data);
	}
	
	public void getlogin()
	{
		login.click();
	}
	

}



