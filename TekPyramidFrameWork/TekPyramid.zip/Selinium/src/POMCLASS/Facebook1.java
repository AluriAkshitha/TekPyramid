package POMCLASS;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Facebook1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://www.facebook.com");
		Facebook fb=new Facebook(driver);
		fb.getCreate();
		Thread.sleep(2000);
		fb.getFirstName("Akshitha");
		Thread.sleep(2000);
		fb.getLastName("Aluri");
		Thread.sleep(2000);
		fb.getEmail("aluriakshitha1111@gamil.com");
		Thread.sleep(2000);
		
		fb.setReEnterEmail("aluriakshitha1111@gamil.com");
		Thread.sleep(2000);
		fb.getPassword("Akki1122");
				Thread.sleep(2000);                                
		
		fb.getDate(15);
		Thread.sleep(2000);
		fb.getMonth("Aug");
		Thread.sleep(2000);
		fb.getyear("2018");
		Thread.sleep(2000);
		fb.getGender();
		fb.getSubmit();
		
		
	}

}
