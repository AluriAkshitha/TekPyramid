package POMCLASS;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoWebShop1 {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://demowebshop.tricentis.com/register");
		Demowebshop dw=new Demowebshop(driver);
         dw.getgenderFemale();
           Thread.sleep(2000);
           dw.getFirstName("Kallem");
           Thread.sleep(2000);
           dw.getLastName("Akshitha");
           Thread.sleep(2000);
           dw.getEmail("aluriakshitha1122@gmail.com");
           Thread.sleep(2000);
           dw.getPassword("Akki1234");
           Thread.sleep(2000);
           dw.getConfirmpassword("Akki1234");
           Thread.sleep(2000);
           dw.getRegister();
           if(driver.getCurrentUrl().contains("https://demowebshop.tricentis.com/register"))
           {
        	   System.out.println("Test is pass :)");
           }
           else
           {
        	   System.out.println("Test case is fail");
           }
           
           
	}

}
