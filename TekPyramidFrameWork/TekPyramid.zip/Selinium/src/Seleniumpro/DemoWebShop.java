package Seleniumpro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoWebShop {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demowebshop.tricentis.com/");
		driver.findElement(By.className("ico-login")).click();
		WebElement email=driver.findElement(By.id("Email"));
		email.sendKeys("aluriakshitha1122@gmail.com");
		WebElement pass=driver.findElement(By.id("Password"));
		pass.sendKeys("AKKI12345@");
		WebElement RememberMe=driver.findElement(By.id("RememberMe"));
		RememberMe.click();
		WebElement login=driver.findElement(By.cssSelector("input[value='Log in']"));
		login.click();
		if(driver.getTitle().contains("Demo Web Shop"))
				{
			System.out.println("Test case is pass :)");
			driver.close();
				}
		else
		{
			System.out.println("Test case is fail :(");
			driver.close();
		}
	}

}
