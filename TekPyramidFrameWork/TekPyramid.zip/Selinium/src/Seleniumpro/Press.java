	package Seleniumpro;
	
	import java.awt.AWTException;
	import java.awt.Robot;
	import java.awt.event.KeyEvent;
	import java.time.Duration;
	
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	
	public class Press {
	
		public static void main(String[] args) throws AWTException, InterruptedException {
			WebDriver driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
			driver.get("https://www.facebook.com/");
			Robot rb=new Robot();
			rb.keyPress(KeyEvent.VK_SHIFT);
			rb.keyPress(KeyEvent.VK_S);
			rb.keyRelease(KeyEvent.VK_S);
			rb.keyRelease(KeyEvent.VK_SHIFT);
			rb.keyPress(KeyEvent.VK_U);
			rb.keyRelease(KeyEvent.VK_U);
			rb.keyPress(KeyEvent.VK_H);
			rb.keyRelease(KeyEvent.VK_H);
			rb.keyPress(KeyEvent.VK_A);
			rb.keyRelease(KeyEvent.VK_A);
			rb.keyPress(KeyEvent.VK_N);
			rb.keyRelease(KeyEvent.VK_N);
			rb.keyPress(KeyEvent.VK_CONTROL);
			rb.keyPress(KeyEvent.VK_A);
			rb.keyRelease(KeyEvent.VK_A);
			rb.keyRelease(KeyEvent.VK_CONTROL);
			rb.keyPress(KeyEvent.VK_CONTROL);
			rb.keyPress(KeyEvent.VK_C);
			rb.keyRelease(KeyEvent.VK_C);
			rb.keyRelease(KeyEvent.VK_CONTROL);
			
			rb.keyPress(KeyEvent.VK_TAB);
			
			rb.keyPress(KeyEvent.VK_CONTROL);
			rb.keyPress(KeyEvent.VK_V);
			rb.keyRelease(KeyEvent.VK_CONTROL);
			rb.keyRelease(KeyEvent.VK_V);
			
			rb.keyRelease(KeyEvent.VK_TAB);	
			Thread.sleep(2000);
			rb.keyPress(KeyEvent.VK_TAB);
			rb.keyRelease(KeyEvent.VK_TAB);
			Thread.sleep(2000);
			String title=driver.getTitle();
			System.out.println(title);
			String url=driver.getCurrentUrl();
			System.out.println(url);
			if(title.contains("Facebook") && url.contains("https://www.facebook.com/"))
			{
			System.out.println("Test case is pass :)");	
			}
			else
			{
				System.out.println("Something Wrong :(");
			}
			//driver.close();
		
		}
			
			
			
			
			
		}
	
	
