package Seleniumpro;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BasedonVerification {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		driver.get("https://demoapps.qspiders.com/ui/radio?sublist=0");
		WebElement upi=driver.findElement(By.name("Attended"));
		if(upi.isDisplayed() && upi.isEnabled())
		{
			upi.click();
			Thread.sleep(2000);
			System.out.println(upi.isSelected());
		}
		else
		{
			System.out.println("Not Displayed or Not Enabled :(");
		}
		driver.close();
	}

}
