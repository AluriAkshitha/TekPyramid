package Seleniumpro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoWebShop1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://demowebshop.tricentis.com/");
		driver.findElement(By.className("ico-register")).click();
		driver.navigate().back();
		driver.findElement(By.className("ico-login")).click();
		driver.navigate().back();
		driver.findElement(By.className("cart-label")).click();
		driver.navigate().back();
		driver.findElement(By.className("wishlist-qty")).click();
		Thread.sleep(2000);
		driver.navigate().refresh();
		driver.quit();
		
		
		
	}

}
