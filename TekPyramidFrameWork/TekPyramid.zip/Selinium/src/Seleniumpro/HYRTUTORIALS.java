package Seleniumpro;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HYRTUTORIALS {

	public static void main(String[] args) {
	
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://www.hyrtutorials.com/");
		WebElement Selinium=driver.findElement(By.xpath("//a[contains(text(),'Selenium Practice')]"));
		Selinium.click();
        WebElement dropdown=driver.findElement(By.xpath("//a[contains(text(),'Dropdowns')]"));
        dropdown.click(); 
	}

}
