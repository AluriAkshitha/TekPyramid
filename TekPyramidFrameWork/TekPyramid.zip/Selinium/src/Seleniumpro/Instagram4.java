package Seleniumpro;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Instagram4{

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://www.instagram.com/");
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("aluriakshitha8855@gmail.com");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Suhan1122@");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		//driver.findElement(By.xpath("//div[style='opacity: 1;']")).click();
		driver.findElement(By.xpath("//span[contains(text(),'Profile')]")).click();
		
		driver.findElement(By.className("_aagv")).click();

}
}
