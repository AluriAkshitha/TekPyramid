package Seleniumpro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Qspiderslogin {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();

		driver.get("https://student.qspiders.com/login");
		WebElement mail=driver.findElement(By.name("email"));
		mail.sendKeys("aluriakshitha8855@gmail.com");
	
		WebElement password=driver.findElement(By.xpath("(//input[contains(@name,'password')])[4]"));
		password.sendKeys("Suhan1122@");
		
		driver.findElement(By.xpath("//button[@type = 'submit']")).click();
		if(driver.getCurrentUrl().contains("https://student.qspiders.com/login"))
				{
			System.out.println("Test case is pass :)");
				}
		else
		{
			System.out.println("Test case is fail :(");
		}
		driver.close();
				
		
	}

}
