package Seleniumpro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Seinium1 {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.selenium.dev/downloads/");
		WebElement Cversion=driver.findElement(By.xpath("//p[text()='C#']/../p[2]"));
		System.out.println(Cversion.getText());
		WebElement Rversion=driver.findElement(By.xpath("//p[text()='Ruby']/../p[2]"));
		System.out.println(Rversion.getText());
		WebElement Jversion=driver.findElement(By.xpath("//p[text()='Java']/../p[2]"));
		System.out.println(Jversion.getText());
		WebElement Pversion=driver.findElement(By.xpath("//p[text()='Python']/../p[2]"));
		System.out.println(Pversion.getText());
		WebElement JSversion=driver.findElement(By.xpath("//p[text()='JavaScript']/../p[2]"));
		System.out.println(JSversion.getText());
		
		driver.quit();
	}
	

}
