package Seleniumpro;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class OrangeHrm
{

	public static void main(String[] args) throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://opensource-demo.orangehrmlive.com/");
		WebElement Username=driver.findElement(By.xpath("//input[@name='username']"));
		Username.sendKeys("Admin");
		Thread.sleep(2000);
		WebElement password=driver.findElement(By.xpath("//input[@name='password']"));
		password.sendKeys("admin123");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		if(driver.getCurrentUrl().contains("https://opensource-demo.orangehrmlive.com/"))
		{
			System.out.println("Test Case is pass");
		}
		else
		{
			System.out.println("Test is fail");
		}
		driver.close();
	}

}
