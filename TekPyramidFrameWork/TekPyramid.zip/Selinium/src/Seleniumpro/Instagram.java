package Seleniumpro;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Instagram {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.instagram.com/");
		Dimension size = driver.manage().window().getSize();
		System.out.println(size.height);
		System.out.println(size.width);
		Point cor = driver.manage().window().getPosition();
		System.out.println(cor.x);
		System.out.println(cor.y);
driver.close();		
		
	}

}
