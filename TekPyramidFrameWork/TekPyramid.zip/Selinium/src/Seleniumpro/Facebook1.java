package Seleniumpro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Facebook1 {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://www.facebook.com/");
		driver.findElement(By.partialLinkText("Forgotten ")).click();
		WebElement number=driver.findElement(By.id("identify_email"));
		number.sendKeys("11223344");
	driver.findElement(By.id("did_submit")).click();
	driver.quit();
		

	}

}
