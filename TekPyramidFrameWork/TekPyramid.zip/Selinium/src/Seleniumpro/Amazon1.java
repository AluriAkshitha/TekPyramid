package Seleniumpro;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Amazon1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
		WebElement search=driver.findElement(By.id("twotabsearchtextbox"));
		search.sendKeys("laptops");
		Thread.sleep(3000);
		List<WebElement> laptop=driver.findElements(By.xpath("//div[text()='laptops']"));
		for(WebElement el1:laptop)
		{
			System.out.println(el1.getText());
		}
		driver.close();
	}
		

	}


