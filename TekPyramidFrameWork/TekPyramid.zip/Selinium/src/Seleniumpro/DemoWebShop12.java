package Seleniumpro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoWebShop12 {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demowebshop.tricentis.com/");
		driver.findElement(By.partialLinkText("Laptop")).click();
		WebElement laptop=driver.findElement(By.xpath("//h1[contains(text(),'Laptop')]/../../div[5]"));
		System.out.println(laptop.getText());
		driver.close();

	}

}
