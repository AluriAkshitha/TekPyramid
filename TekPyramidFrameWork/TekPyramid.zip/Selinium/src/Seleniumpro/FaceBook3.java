package Seleniumpro;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FaceBook3 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://www.facebook.com/");
		WebElement create=driver.findElement(By.xpath("(//a[contains(text(),'Create')])[1]"));
		create.click();
		WebElement firstname=driver.findElement(By.name("firstname"));
		firstname.sendKeys("Akshitha");
		WebElement lastname =driver.findElement(By.name("lastname"));
		lastname.sendKeys("kallem");
		WebElement email=driver.findElement(By.name("reg_email__"));
		email.sendKeys("aluriakshitha2222@gmail.com");
		WebElement password=driver.findElement(By.id("password_step_input"));
		password.sendKeys("12345abc");
		WebElement day=driver.findElement(By.id("day"));
		Select s1=new Select(day);
		s1.selectByIndex(27);
		Thread.sleep(2000);
		WebElement month=driver.findElement(By.id("month"));
		s1=new Select(month);
		s1.selectByVisibleText("Aug");
		Thread.sleep(2000);
		WebElement year=driver.findElement(By.id("year"));
		s1=new Select(year);
		s1.selectByValue("1947");
		WebElement gender=driver.findElement(By.className("_58mt"));
		if(gender.isDisplayed() && gender.isEnabled())
		{
			gender.click();
			Thread.sleep(2000);
			System.out.println(gender.isSelected());
		}
		else
		{
			System.out.println("Not displayed or Not Enabled");
		}
		if(driver.getTitle().contains("Facebook") && driver.getCurrentUrl().contains("https://www.facebook.com/"))
		{
			System.out.println("pass");
		}
		else
		{
			System.out.println("Fail");
		}
		driver.close();

	}

}
