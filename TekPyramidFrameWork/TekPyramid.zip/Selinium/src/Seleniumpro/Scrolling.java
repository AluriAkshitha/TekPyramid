package Seleniumpro;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scrolling {

	public static void main(String[] args) throws AWTException, InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://www.amazon.in/");
		Robot rb=new Robot();
		rb.keyPress(KeyEvent.VK_PAGE_UP);
		rb.keyRelease(KeyEvent.VK_PAGE_UP);
		
//		Thread.sleep(2000);
//		rb.keyPress(KeyEvent.VK_PAGE_DOWN);
//		rb.keyRelease(KeyEvent.VK_PAGE_DOWN);
//		rb.keyPress(KeyEvent.VK_LEFT);
//		rb.keyRelease(KeyEvent.VK_LEFT);
//		rb.keyPress(KeyEvent.VK_RIGHT);
//		rb.keyRelease(KeyEvent.VK_RIGHT);


	}

}
