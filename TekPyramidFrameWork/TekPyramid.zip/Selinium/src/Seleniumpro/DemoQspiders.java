package Seleniumpro;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DemoQspiders {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://demoapps.qspiders.com/ui?scenario=1");
		WebElement MouseActions=driver.findElement(By.xpath("//section[text()='Mouse Actions']"));
		MouseActions.click();
		WebElement drag=driver.findElement(By.xpath("//section[text()='Drag & Drop']"));
		drag.click();
		WebElement position=driver.findElement(By.xpath("//a[text()='Drag Position']"));
		position.click();
		//Mobile
		WebElement MobileCharger=driver.findElement(By.xpath("//div[text()='Mobile Charger']"));
		WebElement MobileCover=driver.findElement(By.xpath("//div[text()='Mobile Cover']"));
		//Laptop
		WebElement LaptopCharger=driver.findElement(By.xpath("//div[text()='Laptop Charger']"));
		WebElement LaptopCover=driver.findElement(By.xpath("//div[text()='Laptop Cover']"));
		
		//Target
		WebElement MobileAccessories=driver.findElement(By.xpath("//div[contains(@class,'drop-column  min-')]"));
		WebElement LaptopAccessories=driver.findElement(By.xpath("//div[contains(@class,'drop-column min-')]"));
		
		//Create Action class
		Actions a1=new Actions(driver);
		
		//Drag and drop
		a1.dragAndDrop(MobileCharger, MobileAccessories).perform();
		a1.dragAndDrop(MobileCover, MobileAccessories).perform();
		a1.dragAndDrop(LaptopCharger,LaptopAccessories).perform();
		a1.dragAndDrop(LaptopCover,LaptopAccessories).perform();
		
		
		
		
		

	}

}
