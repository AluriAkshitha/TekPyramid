package Seleniumpro;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BasedonGetters {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
		WebElement search=driver.findElement(By.id("APjFqb"));
		Point size = search.getLocation();
		System.out.println(size.getX());
		System.out.println(size.getY());
		System.out.println("--------------------------");
		Dimension dim=search.getSize();
		System.out.println(dim.getHeight());
		System.out.println(dim.getWidth());
		System.out.println("---------------------------------");
		Rectangle all=search.getRect();
		System.out.println(all.getX());
		System.out.println(all.getY());
		System.out.println(all.getHeight());
		System.out.println(all.getWidth());
		driver.close();
		
	}

}
