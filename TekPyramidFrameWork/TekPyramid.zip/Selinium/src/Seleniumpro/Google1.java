package Seleniumpro;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Google1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.co.in/");
		WebElement search=driver.findElement(By.id("APjFqb"));
		search.sendKeys("Java");
		Thread.sleep(3000);
		List<WebElement> auto=driver.findElements(By.xpath("//span[text()='java']"));
		for(WebElement el1:auto)
		{
			System.out.println(el1.getText());
		}
		driver.close();
	}

}
