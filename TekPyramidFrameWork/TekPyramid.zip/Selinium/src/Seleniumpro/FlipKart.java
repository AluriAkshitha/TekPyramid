package Seleniumpro;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FlipKart {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.meesho.com/");
		WebElement auto=driver.findElement(By.className("sc-eDvSVe gUjMRV sc-eeMvmM jsHpoY search-input-elm sc-eeMvmM jsHpoY search-input-elm"));
		auto.sendKeys("Laptops");
		List<WebElement> book=driver.findElements(By.className("search-results"));
		for(WebElement el1:book)
		{
			System.out.println(el1.getText());
		}
		driver.close();
	}

	}


