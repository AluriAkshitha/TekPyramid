package Seleniumpro;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragandDrop {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html");
		WebElement oslo=driver.findElement(By.id("box1"));
		WebElement Norway=driver.findElement(By.xpath("//div[text()='Norway']"));
		
		Actions a1=new Actions(driver);
		a1.dragAndDrop(oslo, Norway).perform();
		Thread.sleep(3000);
		WebElement stockholm=driver.findElement(By.id("box2"));
		WebElement Sweden=driver.findElement(By.xpath("//div[text()='Sweden']"));
		a1.dragAndDrop(stockholm, Sweden).perform();
		Thread.sleep(3000);
		
		WebElement Washington=driver.findElement(By.id("box3"));
		WebElement unitedStates=driver.findElement(By.xpath("//div[text()='United States']"));
		a1.dragAndDrop(Washington, unitedStates).perform();
		Thread.sleep(3000);
		WebElement copenhagen =driver.findElement(By.id("box4"));
		WebElement denmark =driver.findElement(By.xpath("//div[text()='Denmark']"));
		a1.dragAndDrop(copenhagen, denmark).perform();
		Thread.sleep(3000);
		WebElement seoul=driver.findElement(By.id("box5"));
		WebElement southkorea =driver.findElement(By.xpath("//div[text()='South Korea']"));
		a1.dragAndDrop(seoul, southkorea).perform();
		Thread.sleep(3000);
		WebElement Rome =driver.findElement(By.id("box6"));
		WebElement Italy=driver.findElement(By.xpath("//div[text()='Italy']"));
		a1.dragAndDrop(Rome, Italy).perform();
		Thread.sleep(3000);
		WebElement Madrid =driver.findElement(By.id("box7"));
		WebElement Spain=driver.findElement(By.xpath("//div[text()='Spain']"));
		a1.dragAndDrop(Madrid, Spain).perform();
		
		
		

	}

}
