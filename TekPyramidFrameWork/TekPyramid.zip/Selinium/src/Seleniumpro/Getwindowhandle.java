package Seleniumpro;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Getwindowhandle {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://kseab.karnataka.gov.in/english");
         Thread.sleep(2000);
         driver.findElement(By.linkText("Photo Gallery")).click();
         String wid=driver.getWindowHandle();
         System.out.println(wid);
          Set<String> wids = driver.getWindowHandles();
          Iterator<String> i=wids.iterator();
          while(i.hasNext())
          {
        	  System.out.println(i.next());
          }
          driver.quit();
          
	}

}
