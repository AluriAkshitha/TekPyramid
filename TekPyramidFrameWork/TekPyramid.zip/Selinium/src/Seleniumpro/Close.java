package Seleniumpro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Close {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://kseab.karnataka.gov.in/english");
		Thread.sleep(2000);
		driver.findElement(By.linkText("Photo Gallery")).click();
		driver.close();

	}

}