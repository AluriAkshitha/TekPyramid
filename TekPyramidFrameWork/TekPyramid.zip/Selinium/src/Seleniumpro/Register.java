package Seleniumpro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Register {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demowebshop.tricentis.com/");
		driver.findElement(By.className("ico-register")).click();
		driver.findElement(By.id("gender-female")).click();
		WebElement firstname=driver.findElement(By.id("FirstName"));
		firstname.sendKeys("Kallem");
		WebElement lastname=driver.findElement(By.id("LastName"));
		lastname.sendKeys("Akshitha");
		WebElement email=driver.findElement(By.id("Email"));
		email.sendKeys("kallemakshitha2929@gmail.com");
		WebElement password=driver.findElement(By.id("Password"));
		password.sendKeys("AKKI112233");
		WebElement confirmpassword=driver.findElement(By.id("ConfirmPassword"));
		confirmpassword.sendKeys("AKKI112233");
		driver.findElement(By.id("register-button")).click();
		if(driver.getTitle().contains("Demo Web Shop"))
		{
	System.out.println("Test case is pass :)");
	
		}
     else
    {
	System.out.println("Test case is fail :(");
	
}
		driver.findElement(By.className("ico-logout")).click();
	}
}
