package Seleniumpro;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selinium {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://www.selenium.dev/");
		driver.findElement(By.xpath("//span[contains(text(),'Downloads')]")).click();
		System.out.println("--------------------------------");
		System.out.println("Selenium - Version #");
		System.out.println("--------------------------------");
		WebElement text=driver.findElement(By.xpath("(//p[contains(@class,'card-title fw-bold h6')])[1]"));
		WebElement Cversion=driver.findElement(By.className("card-link"));
		System.out.println(text.getText()+"\n"+"Version : " + Cversion.getText());
		System.out.println("--------------------------------");
		
		WebElement text1=driver.findElement(By.xpath("(//p[contains(@class,'card-title fw-bold h6')])[2]"));
		WebElement Rversion=driver.findElement(By.className("card-link"));
		System.out.println(text1.getText()+"\n" + "Version : " +Rversion.getText());
		
		System.out.println("--------------------------------");
		WebElement text2=driver.findElement(By.xpath("(//p[contains(@class,'card-title fw-bold h6')])[3]"));
		WebElement Jversion=driver.findElement(By.className("card-link"));
		System.out.println(text2.getText()+"\n"+ "Version : " +Jversion.getText());
	
		System.out.println("--------------------------------");
		WebElement text3=driver.findElement(By.xpath("(//p[contains(@class,'card-title fw-bold h6')])[4]"));
		WebElement Pversion=driver.findElement(By.className("card-link"));
		System.out.println(text3.getText()+"\n"+ "Version : " +Pversion.getText());

		System.out.println("--------------------------------");
		WebElement text4=driver.findElement(By.xpath("(//p[contains(@class,'card-title fw-bold h6')])[5]"));
		WebElement JSversion=driver.findElement(By.className("card-link"));
		System.out.println(text4.getText()+"\n" + "Version : " +JSversion.getText());
		
		driver.quit();
		
		
	}

	
	}


