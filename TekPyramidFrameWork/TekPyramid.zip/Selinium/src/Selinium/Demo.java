package Selinium;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;

public class Demo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the browser");
		String s=sc.next();
		
		if(s.equals("chrome"))
		{
			driver=new ChromeDriver();
		}
		else if(s.equals("Edge"))
		{
		driver=new EdgeDriver();	 
		}
		else if(s.equals("FireFox"))
		{
			driver=new FirefoxDriver();
		}
		else
		{
			System.out.println("Invalid Browser");
		}
		
//		WebElement input = driver.findElement(By.id("input"));
//		
//		
//		Dimension dimension=new Dimension(1000,800);
//		driver.manage().window().setSize(dimension);
//		
//		Point point = new Point(200,200);
//		driver.manage().window().setPosition(point);
		
		driver.navigate().to("https://demowebshop.tricentis.com/");
		WebElement computers = driver.findElement(By.xpath("(//li[@class='inactive'])[2]"));
		
		Actions a1=new Actions(driver);
		a1.moveToElement(computers).perform();
		a1.contextClick(computers).perform();
		
		TakesScreenshot ts=(TakesScreenshot)driver;
		File temp = ts.getScreenshotAs(OutputType.FILE);
		File perm = new File("./Screenshot/Demo.png");
         FileHandler.copy(temp, perm);
         driver.close();

}
}
