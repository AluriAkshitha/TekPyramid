package Selinium;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PetsStore1 {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://petstore.octoperf.com/");
		CatsPomClass pm=new CatsPomClass(driver);
		pm.getEnteraStore();
		pm.getSignIn();
		pm.getUsername("1234567890");
		pm.getPassword();
		pm.getPassword1("123450");
		pm.getLogin();
		pm.getCatsClick();
		pm.getProductId();
		pm.getAddToCart();
		pm.getQuantity1();
		pm.getQuantity("10");
		pm.getUpdate();
		pm.getProccedToCheckOut();
		pm.getNewOrder();
		pm.getConfirm();

	}

}
