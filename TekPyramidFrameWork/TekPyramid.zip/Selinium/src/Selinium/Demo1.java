package Selinium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo1 {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demowebshop.tricentis.com/");
		driver.findElement(By.xpath("//a[normalize-space()='Register']")).click();
        driver.findElement(By.xpath("//input[@id='gender-female']")).click();
        driver.findElement(By.xpath("//input[@id='FirstName']")).sendKeys("Akshitha");
        driver.findElement(By.xpath("(//input[@id='LastName'])[1]")).sendKeys("Kallem");
        driver.findElement(By.xpath("//input[@id='Email']")).sendKeys("aluriakshitha1122@gmail.com");
	driver.findElement(By.xpath("(//input[@id='Password'])[1]")).sendKeys("Akki123@");
	driver.findElement(By.xpath("(//input[@id='ConfirmPassword'])[1]")).sendKeys("Akki123@");
driver.findElement(By.xpath("(//input[@id='register-button'])[1]")).click();
}
}
