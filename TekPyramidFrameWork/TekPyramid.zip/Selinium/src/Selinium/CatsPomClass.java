package Selinium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CatsPomClass {
	
	@FindBy(xpath="//a[text()='Enter the Store']")
	private WebElement EnteraStore;
	
	@FindBy(linkText="Sign In")
	private WebElement SignIn;
	
	@FindBy(name="username")
	private WebElement Username;
	
	@FindBy(name="password")
	private WebElement Password;
	
	@FindBy(name="password")
	private WebElement Password1;
	
	@FindBy(name="signon")
	private WebElement Login;
	
	@FindBy(xpath="//div[@id='Content']//a[3]")
	private WebElement CatsClick;
	
	@FindBy(linkText="FL-DSH-01")
	private WebElement ProductId;
	
	@FindBy(linkText="Add to Cart")
	private WebElement AddToCart;
	
	
	
	@FindBy(name="EST-14")
	private WebElement Quantity1;
	
	@FindBy(name="EST-14")
	private WebElement Quantity;
	
	@FindBy(name="updateCartQuantities")
	private WebElement Update;
	
	@FindBy(linkText="Proceed to Checkout")
	private WebElement ProccedToCheckOut;
	
	@FindBy(name="newOrder")
	private WebElement NewOrder;
	
	@FindBy(linkText="Confirm")
	private WebElement Confirm;
	
	public CatsPomClass(WebDriver driver)
	{
		PageFactory.initElements(driver,this);
	}
	
	public void getEnteraStore()
	{
		EnteraStore.click();	
	}

	public void getSignIn() {
		SignIn.click();
	}

	public void getUsername(String data) {
		Username.sendKeys(data);
	}

	public void getPassword() {
		Password.clear();
		
	}

	public void getPassword1(String data) {
		Password1.sendKeys(data);
	}

	public void getLogin() {
		Login.click();
	}

	public void getCatsClick() {
		CatsClick.click();
	}

	public void getProductId() {
		ProductId.click();
	}


	public void getAddToCart() {
		AddToCart.click();
	}
	
	public void getQuantity1()
	{
		Quantity1.clear();
	}
	public void getQuantity(String data) {
		 Quantity.sendKeys(data);
	}

	public void getUpdate() {
		Update.click();	
	}

	
	public void getProccedToCheckOut() {
	  ProccedToCheckOut.click();
	}

	public void getNewOrder() {
		NewOrder.click();;
	}
   public void getConfirm() {
		Confirm.click();;
	}


}
