package Selinium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PomDemo {

	@FindBy(xpath="//a[normalize-space()='Register']")
	private WebElement Register;
	
	@FindBy(xpath="//input[@id='gender-female']")
	private WebElement Gender;
	
	@FindBy(xpath="//input[@id='FirstName']")
	private WebElement FirstName;
	
	
	@FindBy(xpath="(//input[@id='LastName'])[1]")
	private WebElement LastName ;
	
	
	@FindBy(xpath="//input[@id='Email']")
	private WebElement Email;
	
	
	@FindBy(xpath="(//input[@id='Password'])[1]")
	private WebElement Password ;
	
	
	@FindBy(xpath="(//input[@id='ConfirmPassword'])[1]")
	private WebElement ConfirmPassword;
	
	@FindBy(xpath="(//input[@id='register-button'])[1]")
	private WebElement RegisterButton;
	
	public PomDemo(WebDriver driver)
	{
		PageFactory.initElements(driver,this);
	}

	public WebElement getRegister() {
		return Register;
	}

	public WebElement getGender() {
		return Gender;
	}

	public WebElement getFirstName() {
		return FirstName;
	}

	public WebElement getLastName() {
		return LastName;
	}

	public WebElement getEmail() {
		return Email;
	}

	public WebElement getPassword() {
		return Password;
	}

	public WebElement getConfirmPassword() {
		return ConfirmPassword;
	}

	public WebElement getRegisterButton() {
		return RegisterButton;
	}
}
