package Selinium;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;

public class Skill {

	public static void main(String[] args) throws InterruptedException, IOException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://demoapp.skillrary.com/");
		WebElement course = driver.findElement(By.id("course"));
		
		Actions a1=new Actions(driver);
		a1.moveToElement(course).perform();
		Thread.sleep(2000);
		WebElement selinium = driver.findElement(By.xpath("(//a[text()='selenium'])[1]"));
		
		selinium.click();
		WebElement image=driver.findElement(By.className("zoom"));
		File temp=image.getScreenshotAs(OutputType.FILE);
		System.out.println(temp);
		File perm=new File("./ScreenShot/selinium.png");
		System.out.println(perm);
		FileHandler.copy(temp, perm);
		driver.quit();
	}
		
		
	}


