package Selinium;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.TargetLocator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;

public class HYR {

	private static final CharSequence Akshitha = null;

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://www.hyrtutorials.com/");
		WebElement selenium = driver.findElement(By.xpath("//a[text()='Selenium Practice']"));

		Actions a1=new Actions(driver);
		a1.moveToElement(selenium).perform();
		
	
		WebElement Alerts = driver.findElement(By.linkText("Alerts"));
		Thread.sleep(2000);
		a1.click(Alerts).perform();
		WebElement alertBox=driver.findElement(By.id("alertBox"));
		alertBox.click();
		Alert alert = driver.switchTo().alert();
		String text=alert.getText();
		System.out.println(text);
		alert.accept();
		Thread.sleep(2000);
		System.out.println("-----------------------------------------");
		WebElement confirmBox=driver.findElement(By.id("confirmBox"));
		confirmBox.click();
		System.out.println(alert.getText());
		Thread.sleep(2000);
		alert.dismiss();
		WebElement promptBox=driver.findElement(By.xpath("//button[@id='promptBox']"));
		
		promptBox.click();
		promptBox.clear();
		alert.sendKeys("Akshitha");
		System.out.println(alert.getText());
		Thread.sleep(2000);
		alert.accept();
		driver.close();
	
}

}
