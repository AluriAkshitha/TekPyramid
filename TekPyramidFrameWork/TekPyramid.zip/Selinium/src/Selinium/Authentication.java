package Selinium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Authentication {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://admin:admin@the-internet.herokuapp.com/basic_auth");
		WebElement con=driver.findElement(By.xpath("//p[contains(text(),'Congratulations')]"));
		if(con.getText().contains("Congratulations"))
		{
			System.out.println("Test Case is pass :)");
		}
		else
		{
			System.out.println("Test Case is fail :(");
		}
		driver.close();

	}

}
