package Selinium;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PetStore {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://petstore.octoperf.com/");
		if(driver.getCurrentUrl().contains("https://petstore.octoperf.com/"))
		{
			System.out.println("Application launched Successfully :)");
		}
		else
		{
			System.out.println("Wrong url");
		}
		driver.findElement(By.xpath("//a[text()='Enter the Store']")).click();
		driver.findElement(By.xpath("//a[text()='Sign In']")).click();
//	driver.findElement(By.xpath("//a[text()='Register Now!']")).click();
//
//	Thread.sleep(2000);
//		driver.findElement(By.name("username")).sendKeys("1234567890");
//		driver.findElement(By.name("password")).sendKeys("123450");
//	driver.findElement(By.name("repeatedPassword")).sendKeys("123450");
//		driver.findElement(By.name("account.firstName")).sendKeys("Kallem");
//		driver.findElement(By.name("account.lastName")).sendKeys("Akshitha");
//		driver.findElement(By.name("account.email")).sendKeys("aluriakshitha2222@gmail.com");
//	driver.findElement(By.name("account.phone")).sendKeys("9988776655");
//		driver.findElement(By.name("account.address1")).sendKeys("Medchal");
//   	driver.findElement(By.name("account.address2")).sendKeys("Ragavendra Nagar colony");
//		driver.findElement(By.name("account.city")).sendKeys("Hyderabad");
//		driver.findElement(By.name("account.state")).sendKeys("Telangana");
//		driver.findElement(By.name("account.zip")).sendKeys("504401");
//		driver.findElement(By.name("account.country")).sendKeys("India");
//		driver.findElement(By.name("newAccount")).click();
//		
		driver.findElement(By.name("username")).sendKeys("1234567890");
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys("123450");
		driver.findElement(By.name("signon")).click();
		driver.findElement(By.xpath("//*[@id=\"SidebarContent\"]/a[2]")).click();
		

			
		  WebElement table = driver.findElement(By.xpath("//table"));

         
          List<WebElement> rows = table.findElements(By.tagName("tr"));
          
          System.out.println("Dog Names:");
          
          for (int i = 1; i < rows.size(); i++) 
          { 
              List<WebElement> cells = rows.get(i).findElements(By.tagName("td"));
              if (cells.size() > 1) 
              {
                 
                  System.out.println(cells.get(1).getText());
              }
}
          driver.findElement(By.xpath("a[text()='Sign Out]")).click();
          
          driver.quit();
          
          
          
}
}

