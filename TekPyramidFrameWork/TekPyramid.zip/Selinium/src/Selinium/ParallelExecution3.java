package Selinium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ParallelExecution3 {
	WebDriver driver;
	@BeforeMethod
	public void OpenBrowser()
	{
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://petstore.octoperf.com/");
		
	}
	@Test
	
   public void Login()
{
		driver.findElement(By.xpath("//a[text()='Enter the Store']")).click();
		driver.findElement(By.xpath("//a[text()='Sign In']")).click();
		driver.findElement(By.name("username")).sendKeys("1234567890");
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys("123450");
		driver.findElement(By.name("signon")).click();
		
		
}
	
	@AfterMethod
	public void Closebrowser()
	{
	if(driver.getCurrentUrl().contains("https://petstore.octoperf.com/actions/Catalog.action"))
	{
		Reporter.log("TestCase is pass",true);
	}
	else
	{
		Reporter.log("Test Case is fail",true);
	}
	driver.close();
     }
     }


