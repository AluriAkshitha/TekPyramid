package Selinium;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HYRTUTORIALS {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://www.hyrtutorials.com/");
		WebElement selenium = driver.findElement(By.xpath("//a[text()='Selenium Practice']"));

		Actions a1=new Actions(driver);
		a1.moveToElement(selenium).perform();
		
		WebElement windowHandles = driver.findElement(By.partialLinkText("Window "));
		a1.click(windowHandles).perform();
		
		WebElement newWindowBtn=driver.findElement(By.id("newWindowBtn"));
		newWindowBtn.click();
		
		String parent=driver.getWindowHandle();
		 
		
		Set<String> childwindow = driver.getWindowHandles();
		for(String id:childwindow)
		{
			if(!id.equals(parent))
			{
				driver.switchTo().window(id);
				WebElement firstname = driver.findElement(By.id("firstName"));
				firstname.sendKeys("kallem");
				Thread.sleep(2000);
				WebElement lastname = driver.findElement(By.id("lastName"));
				lastname.sendKeys("Akshitha");
				Thread.sleep(2000);
				WebElement gender = driver.findElement(By.id("femalerb"));
			    gender.click();
			    Thread.sleep(2000);
		        Thread.sleep(2000);
		        WebElement language = driver.findElement(By.id("englishchbx"));
		        language.click();
		        Thread.sleep(2000);
	            WebElement email = driver.findElement(By.id("email"));
	            email.sendKeys("9900990099");
	            Thread.sleep(2000);
	            WebElement password = driver.findElement(By.id("password"));
                password.sendKeys("9999999999");
                Thread.sleep(2000);
                WebElement registerbtn= driver.findElement(By.id("registerbtn"));
                registerbtn.click();
                 WebElement clear= driver.findElement(By.id("clearbtn"));
                clear.click();
                driver.close();
			}
                else
                {
                	
                }
   
				
			}
		}
	}


