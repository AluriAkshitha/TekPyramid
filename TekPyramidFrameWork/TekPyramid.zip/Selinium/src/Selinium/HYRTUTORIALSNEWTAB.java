package Selinium;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class HYRTUTORIALSNEWTAB {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://www.hyrtutorials.com/");
		WebElement selenium = driver.findElement(By.xpath("//a[text()='Selenium Practice']"));

		Actions a1=new Actions(driver);
		a1.moveToElement(selenium).perform();
		WebElement windowHandles = driver.findElement(By.partialLinkText("Window "));
		a1.click(windowHandles).perform();
		
		String parent=driver.getWindowHandle();
		
		WebElement newTabBtn=driver.findElement(By.id("newTabBtn"));
		newTabBtn.click();

       Set<String> childwindow = driver.getWindowHandles();
		for(String id:childwindow)
		{
			if(!id.equals(parent))
			{
				driver.switchTo().window(id);
				driver.findElement(By.id("alertBox")).click();
				String alert=driver.switchTo().alert().getText();
				System.out.println(alert);
				driver.switchTo().alert().accept();
				Thread.sleep(2000);
				
				driver.findElement(By.id("confirmBox")).click();
		        String confirm = driver.switchTo().alert().getText();
		        System.out.println(confirm);
				driver.switchTo().alert().dismiss();
				
				
				
				Thread.sleep(2000);
				
				driver.findElement(By.xpath("//button[@id='promptBox']"));
			String prompt = driver.switchTo().alert().getText();
			System.out.println(prompt);
				driver.switchTo().alert().sendKeys("Akshitha");
				
				
				driver.close();
				
	}

		}
	}
}
