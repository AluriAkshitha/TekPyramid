package DD;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Loginfb {

	public static void main(String[] args) throws EncryptedDocumentException, IOException, InterruptedException {
		// TODO Auto-generated method stub
		
				FileInputStream fis=new FileInputStream("./Excel1/fblogin.xlsx");
		Workbook book=WorkbookFactory.create(fis);
		String url=book.getSheet("Sheet1").getRow(0).getCell(0).toString();
		System.out.println(url);
		
		String username=book.getSheet("Sheet1").getRow(0).getCell(1).toString();
		System.out.println(username);
	
		String password=book.getSheet("Sheet1").getRow(0).getCell(2).toString();
		System.out.println(password);
		
	book.close();
	
	WebDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	
	driver.get(url);
	Thread.sleep(2000);
	
	driver.findElement(By.id("email")).sendKeys(username);
	Thread.sleep(2000);
	
	driver.findElement(By.id("pass")).sendKeys(password);
	Thread.sleep(2000);
	
		
		driver.findElement(By.name("login")).click();
		
		Thread.sleep(2000);
		//driver.close();

	}

}
