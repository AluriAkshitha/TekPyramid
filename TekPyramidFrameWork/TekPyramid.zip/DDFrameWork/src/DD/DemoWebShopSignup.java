package DD;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoWebShopSignup {
	static WebDriver driver;
	public void OpenBrower(WebDriver driver) throws EncryptedDocumentException, IOException, InterruptedException
	{
		FileInputStream fis=new FileInputStream("./Excel1/Demos.xlsx");
		Workbook book=WorkbookFactory.create(fis);
		String url=book.getSheet("Sheet1").getRow(0).getCell(1).toString();
		System.out.println(url);
		Thread.sleep(2000);
		String firstname=book.getSheet("Sheet1").getRow(1).getCell(1).toString();
		System.out.println(firstname);
		Thread.sleep(2000);
		String lastname=book.getSheet("Sheet1").getRow(2).getCell(1).toString();
		System.out.println(lastname);
		String email=book.getSheet("Sheet1").getRow(3).getCell(1).toString();
		System.out.println(email);
		String password=book.getSheet("Sheet1").getRow(4).getCell(1).toString();
		System.out.println(password);
		
		String confirmpassword=book.getSheet("Sheet1").getRow(5).getCell(1).toString();
		System.out.println(confirmpassword);
		
		PomDemo pm=new PomDemo(driver);
		driver.get(url);
		pm.getFemale();
		pm.getFirstName(firstname);
		pm.getLastName(lastname);
		pm.getEmail(email);
		pm.getPassword(password);
		pm.getConfirmPassword(confirmpassword);
		pm.getRegister();
	}

	public static void main(String[] args) throws EncryptedDocumentException, IOException, InterruptedException {
		DemoWebShopSignup dm=new DemoWebShopSignup();
		dm.OpenBrower(new ChromeDriver());
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
	}
}
