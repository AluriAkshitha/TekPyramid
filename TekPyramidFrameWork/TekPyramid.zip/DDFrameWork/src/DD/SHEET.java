package DD;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class SHEET {

	public static void main(String[] args) throws EncryptedDocumentException, IOException {
	FileInputStream fis=new FileInputStream("./Excel1/Excel.xlsx");
	Workbook book=WorkbookFactory.create(fis);
	book.createSheet("Sample");
	FileOutputStream fos=new FileOutputStream("./Excel1/Excel.xlsx");
	book.write(fos);
	System.out.println("Sheet is created");
	}

}
