package DD;

import java.time.Duration;

import org.openqa.selenium.WebDriver;

public class Sample1 {
	public void OpenBrowser(WebDriver driver,String url)
	{
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get(url);
	}

}
