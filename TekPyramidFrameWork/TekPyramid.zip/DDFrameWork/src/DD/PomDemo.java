package DD;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PomDemo {
	@FindBy(id="gender-female")
	WebElement Gender;
	
	@FindBy(id="FirstName")
	WebElement FirstName;
	
	@FindBy(id="LastName")
	WebElement LastName;
	
	@FindBy(id="Email")
	WebElement Email;
	
	@FindBy(id="Password")
	WebElement Password;
	
	@FindBy(id="ConfirmPassword")
	WebElement ConfirmPassword;
	
	@FindBy(id="register-button")
	WebElement Register;
	
	public PomDemo(WebDriver driver)
	
	{
		PageFactory.initElements(driver,this);
	}
	
	public void getFemale()
	{
	  Gender.click();
	}
	
	public void getFirstName(String data)
	{
	  FirstName.sendKeys(data);
	}
	public void getLastName(String data)
	{
	 LastName.sendKeys(data);
	}
	
	public void getEmail(String data)
	{
		Email.sendKeys(data);
	}
	
	public void getPassword(String data)
	{
		Password.sendKeys(data);
	}
	
	public void getConfirmPassword(String data)
	{
		ConfirmPassword.sendKeys(data);
	}
	public void getRegister()
	{
		Register.click();
	}

}



