package DD;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Facebook {

	public static void main(String[] args) throws IOException {
		FileInputStream Fis=new FileInputStream("./properties/Data.properties");
		Properties pr=new Properties();
		pr.load(Fis);
		String url=pr.getProperty("URL");
		System.out.println(url);
		String UN=pr.getProperty("UserName");
		System.out.println(UN);
String PW=pr.getProperty("Password");
System.out.println(PW);
		
		

	}

}
