  package DD;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class Facebook3 {

	public static void main(String[] args) throws IOException  {
//		FileInputStream Fis=new FileInputStream("./properties/Data.properties");
//		Properties pr=new Properties();                   
//		pr.load(Fis);
//		Set<Entry<Object, Object>> entry = pr.entrySet();
//		Iterator<Entry<Object, Object>> i = entry.iterator();
//		while(i.hasNext())
//		{
//			System.out.println(i.next());
//		}
	}
}


