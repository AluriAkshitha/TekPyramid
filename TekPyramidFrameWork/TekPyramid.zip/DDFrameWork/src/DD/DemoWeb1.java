package DD;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoWeb1 {
	static WebDriver driver;
	public void OpenBrowser(WebDriver driver) throws IOException
	{
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		FileInputStream fis=new FileInputStream("./properties/DEMO.properties");
		
		Properties pr=new Properties();
		pr.load(fis);
		String Url= pr.getProperty("url");
		driver.get(Url);
		String username = pr.getProperty("username");
		String password = pr.getProperty("password");
		
		
		System.out.println(username);
		System.out.println(password);
		
		DemoWeB2 dm1=new DemoWeB2(driver);
		
		dm1.getEmail(username);
		dm1.getPassword(password);
		dm1.getLogin();
		}

	public static void main(String[] args) throws IOException {
		
		DemoWeb1 dm=new DemoWeb1();
	
		dm.OpenBrowser(new ChromeDriver());
		
		
		
		 
		 
	}

}
