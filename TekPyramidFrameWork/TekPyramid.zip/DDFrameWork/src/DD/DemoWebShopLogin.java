package DD;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoWebShopLogin {

	public static void main(String[] args) throws EncryptedDocumentException, IOException {
		
		FileInputStream fis=new FileInputStream("./Excel1/Demo.xlsx");
		
		Workbook book=WorkbookFactory.create(fis);
		
		String url=book.getSheet("Sheet1").getRow(0).getCell(0).toString();
		System.out.println(url);
		
		String username=book.getSheet("Sheet1").getRow(0).getCell(1).toString();
		System.out.println(username);
	
		String password=book.getSheet("Sheet1").getRow(0).getCell(2).toString();
		System.out.println(password);
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		DemoWebshop dm=new DemoWebshop(driver);
		
		
		driver.get(url);
		dm.getEmail(username);
		
		dm.getPassword(password);
		dm.getLogin();
		
		book.close();
		

	}

}
