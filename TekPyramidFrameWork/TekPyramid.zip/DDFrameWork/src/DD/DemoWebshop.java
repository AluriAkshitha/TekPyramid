package DD;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DemoWebshop {

	@FindBy(id="Email")
	private WebElement Email;
	
	@FindBy(id="Password")
	private WebElement Password;
	
	@FindBy(xpath="//input[@value='Log in']")
	private WebElement Login;
	
	public DemoWebshop(WebDriver driver)
	{
		PageFactory.initElements(driver,this);
	}
	
	public void getEmail(String data)
	{
		Email.sendKeys(data);
		
	}
	
	public void getPassword(String data)
	{
		Password.sendKeys(data);
		
	}
	public void getLogin()
	{
		Login.click();
	}
	
}
