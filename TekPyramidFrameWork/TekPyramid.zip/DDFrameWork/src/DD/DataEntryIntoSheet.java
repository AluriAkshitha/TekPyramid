package DD;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class DataEntryIntoSheet {

	public static void main(String[] args) throws EncryptedDocumentException, IOException {
		FileInputStream fis=new FileInputStream("./Excel1/Excel.xlsx");                       
		
		Workbook book=WorkbookFactory.create(fis);
		book.getSheet("Sample").createRow(0).createCell(0).setCellValue("Java");
		
		book.getSheet("Sample").createRow(1).createCell(0).setCellValue("Java");
		
		FileOutputStream fos=new FileOutputStream("./Excel1/Excel.xlsx");
		book.write(fos);
		
		
		
		System.out.println("Data is written :)");

	}

}
