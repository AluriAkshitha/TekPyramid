package DD;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;

public class FaceBook1 {

	public static void main(String[] args) throws IOException  {
		// TODO Auto-generated method stub
		FileInputStream Fis=new FileInputStream("./properties/Data.properties");
		Properties pr=new Properties();
		pr.load(Fis);
		Collection<Object> values = pr.values();
		Iterator<Object> i = values.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}

	}

}
