package DD;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;

public class Sample2 {
	
	public String getData(String Key) throws IOException
	{
		FileInputStream fis=new FileInputStream("./properties/Data.properties");
		
		Properties pr=new Properties();
		pr.load(fis);
		String data = pr.getProperty(Key);
		return data;
		
	}
	

	public static void main(String[] args) throws IOException {
		
		Sample2 s2=new Sample2();
		 String value = s2.getData("URL");
		 Sample1 s3=new Sample1();
		 s3.OpenBrowser(new ChromeDriver(),value);
		 System.out.println(value);
	}

}
