package Optim;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class BoardAutomation {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://trello.com");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[text()='Log in']")).click();
		driver.findElement(By.name("username")).sendKeys("aluriakshitha8855@gmail.com");
		driver.findElement(By.xpath("//span[text()='Continue']")).click();
		driver.findElement(By.name("password")).sendKeys("Akki1122@");
		driver.findElement(By.xpath("//span[text()='Log in']")).click();
		
		driver.findElement(By.xpath("//span[text()='Boards']")).click();
		driver.findElement(By.xpath("//p[text()='Create']")).click();
		driver.findElement(By.className("kgXqyT2weJmrQm")).click();
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Interview Tasks");
		driver.findElement(By.partialLinkText("Start")).click();
		driver.findElement(By.xpath("//div[text()='Company Overview']")).click();
		driver.findElement(By.xpath("//button[text()='Create']")).click();
		driver.findElement(By.cssSelector("span[class='board-tile-fade']")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.findElement(By.className("oe8RymzptORQ7h")).sendKeys("To Do");
		driver.findElement(By.xpath("//button[text()='Add list']")).click();
		
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.findElement(By.className("oe8RymzptORQ7h")).sendKeys("In Progress");
		driver.findElement(By.xpath("//button[text()='Add list']")).click();
		
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.findElement(By.className("oe8RymzptORQ7h")).sendKeys("Done");
		driver.findElement(By.xpath("//button[text()='Add list']")).click();
		
		driver.findElement(By.xpath("//button[text()='Add card']")).click();

		
		driver.findElement(By.className("qJv26NWQGVKzI9")).sendKeys("Project");
		driver.findElement(By.xpath("//button[text()='Add card']")).click();
		
		driver.findElement(By.xpath("//button[text()='Add card']")).click();
		driver.findElement(By.className("qJv26NWQGVKzI9")).sendKeys("Projectplan");
		
		driver.findElement(By.xpath("//button[text()='Add card']")).click();
		driver.findElement(By.xpath("//button[text()='Add card']")).click();
		driver.findElement(By.className("qJv26NWQGVKzI9")).sendKeys("ProjectTest");
		driver.findElement(By.xpath("//button[text()='Add card']")).click();
		
		Actions a1=new Actions(driver);
		a1.moveToElement(null).perform();
		driver.findElement(By.id("")).click();
		
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.findElement(By.xpath("//div[text()='In progress']")).click();
		
		a1.moveToElement(null).perform();
		driver.findElement(By.id("")).click();
		
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.findElement(By.xpath("//div[text()='Done']")).click();
		
		String Actualtitle="Interview Tasks";
		String Expectedtitle="Interview Tasks";
		
		if(Actualtitle.equals(Expectedtitle))
		{
			System.out.println("Title is displayed");
		}
		else
		{
			System.out.println("Title is not displayed");
		}
		
		String ToDotasksActual1="Project";
		String ToDotasksexpected1="Project";
		if(ToDotasksActual1.endsWith(ToDotasksexpected1))
		{
			System.out.println("task is displayed");
		}
		else
		{
			System.out.println("task not is displayed");
		}
		String ToDotasksActual2="Projectplan";
		String ToDotasksexpected2="Projectplan";
		if(ToDotasksActual2.endsWith(ToDotasksexpected2))
		{
			System.out.println("task is displayed");
		}
		else
		{
			System.out.println("task not is displayed");
		}
		String ToDotasksActual3="ProjectTest";
		String ToDotasksexpected3="ProjectTest";
		if(ToDotasksActual3.endsWith(ToDotasksexpected3))
		{
			System.out.println("task is displayed");
		}
		else
		{
			System.out.println("task not is displayed");
		}
	driver.findElement(By.xpath("//div[text()='In progress']"));
	String actualtitle="Projectplan";
	String expectedtitle1="Projectplan";
	if(actualtitle.equals(expectedtitle1))
	{
		System.out.println("Is diplayed");
	}
	else
	{
		System.out.println("Is not displayed");
	}
	driver.findElement(By.xpath("//div[text()='Done']"));
	String actualtitle1="ProjectTest";
	String expectedtitle2="ProjectTest";
	if(actualtitle1.equals(expectedtitle2))
	{
		System.out.println("Is displayed");
	}
	else
	{
		System.out.println("Is not displayed");
	}
		
		driver.close();
	}

}
