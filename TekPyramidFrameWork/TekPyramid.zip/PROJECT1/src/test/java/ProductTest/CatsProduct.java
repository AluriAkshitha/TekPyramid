package ProductTest;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;



import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.model.Report;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CatsProduct {
	WebDriver driver;
	ExtentSparkReporter spark;
	ExtentReports report;
	public ExtentTest test;
	

//	  @Parameters("BowserName")
	
	
	@BeforeSuite
	public void suiteSetup()
	{
		//Create the SparkReport
		spark = new ExtentSparkReporter("./AdvanceReports/CatProductreport.html");
		
		//Configure the SparkReport Information
		spark.config().setDocumentTitle("Functionality Testing for the CatsProduct");
		spark.config().setReportName("RegressionSuite||Verification of Cats Products");
		spark.config().setTheme(Theme.STANDARD);
		
		//Create the Extent Report
         report = new ExtentReports();
		
		//Attach the spark report and Extent Report
		report.attachReporter(spark);
		
		//Configure the System Information
		report.setSystemInfo("DeviceName","Akshitha");
		report.setSystemInfo("OperatingSystems","WINDOWS 11");
		report.setSystemInfo("Browser","Chrome");
		report.setSystemInfo("BrowserVersion","chrome-128.0.6613.85");
		
	}
	@AfterSuite
	public void suiteTerminateSetup()
	{
		report.flush();
	}
	
	@Parameters("BrowserName")
	@BeforeClass
		public void browserSetup(String browser)
		{
		
		 
		 test = report.createTest("Browser Setup");
		 
		 test.log(Status.INFO, "----Execution started successfully----");
		 
		 test.log(Status.INFO, "Launching the browser successfully");

		  Reporter.log("Browser Launched Successful",true);
		if(browser.equals("chrome"))
		{
	//Launch the Browser-Chrome		
			WebDriverManager.chromedriver().setup();
	         driver=new ChromeDriver();
		}
		else if(browser.equals("edge"))
		{
	//Launch the Browser-Edge
			WebDriverManager.chromedriver().setup();
			driver=new EdgeDriver();
		}
		else if(browser.equals("firefox"))
		{
	//Launch the Browser-FireFox
			WebDriverManager.chromedriver().setup();
			driver=new FirefoxDriver();
		}
		else
		{
			Reporter.log("Enter Valid Browsername",true);
			Reporter.log("So i Will be run Default Browser",true);
			WebDriverManager.chromedriver().setup();
	         driver=new ChromeDriver();
		}
   //Maximize the Browser
		driver.manage().window().maximize();
		}
		
	  
	  @BeforeMethod
		public void signIn()
		{
		  test = report.createTest("Verifying signin page");
		  
		  test.log(Status.INFO, "---- Sign In Execution started successfully----");
		  
		  
			Reporter.log("SignIn Execution Start Successful",true);
			
	//Step 1.2 Navigate To the Application
			driver.get("https://petstore.octoperf.com/");
			
	//Step Click On 'Enter a Store' to signin
			driver.findElement(By.xpath("//a[text()='Enter the Store']")).click();
			
	//Step 5 Click on 'SignIn' Link
			driver.findElement(By.xpath("//a[text()='Sign In']")).click();
			
	//Step 5.1 Enter the UserId
			driver.findElement(By.name("username")).sendKeys("1234567890");
			
	//Step 5.2 Enter the Password
			
			
			driver.findElement(By.name("password")).clear();
			
			test.log(Status.PASS, "Clear action is done successfully - password text field");
			driver.findElement(By.name("password")).sendKeys("123450");
			
	//Step 5.3 Click On Login
			driver.findElement(By.name("signon")).click();
			
			Reporter.log("SignIn Done Successfully",true);
			
			 test.log(Status.INFO, "----Execution completed successfully----");
		}
		
 @AfterMethod
		public void signOut()
		{
			Reporter.log("SignOut Started Successfully",true);
			
	//Click on SignOut Button
			driver.findElement(By.linkText("Sign Out")).click();
			
			Reporter.log("SignOut Done Successfully",true);
		}
		
 @AfterClass
		public void browserTerminate()
		{
			driver.quit();
		
			Reporter.log("Browser Terminated Successfully",true);	
		}
		
		
 @Test
		public void addFirstProduct() throws IOException
		{
	//Waiting Statement
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
	//Clicking on Cats
			driver.findElement(By.xpath("//*[@id=\"SidebarContent\"]/a[3]")).click();
			

	//Click On First CatName-Manx
			driver.findElement(By.xpath("//a[text()='FL-DSH-01']")).click();
			
	//Click on First ItemId=EST-14
			driver.findElement(By.linkText("EST-14")).click();
			
	//Click on AddToCart
			driver.findElement(By.linkText("Add to Cart")).click();
			
	//Change the Quantity
			driver.findElement(By.name("EST-14")).clear();
			driver.findElement(By.name("EST-14")).sendKeys("10");
			
	//Click on Proceed To CheckOut
			driver.findElement(By.linkText("Proceed to Checkout"));
			
	//Click on Continue		
			driver.findElement(By.xpath("//input[@type='submit']")).click();
	
	//Click on Confirm
			driver.findElement(By.tagName("a")).click();
			
			Reporter.log("Successfully Confirm the Order.", true);
			
			WebElement Confirm_Message = driver.findElement(By.xpath("//li[normalize-space()='Thank you, your order has been submitted.']"));
			
			if(Confirm_Message.isDisplayed())
			{
				Reporter.log("Thank you, your order has been submitted.", true);
				test.pass("Order was successfully submitted.");
			}
			else
			{
				Reporter.log("Thank you, your order has not been submitted.", true);
				 test.fail("Order submission failed.");
			}
			TakesScreenshot ts = (TakesScreenshot)driver;
			
			File temp = ts.getScreenshotAs(OutputType.FILE);
			
			File perm = new File("./ScreenShots/Catsorder.png");
			
			FileHandler.copy(temp, perm);
			
			Reporter.log("ScreenShots saved at:"+perm.getAbsolutePath(), true);
			test.addScreenCaptureFromPath(perm.getAbsolutePath());
				
			
	
		}
  @Test(dependsOnMethods="addFirstProduct")
		public void removeFirstProduct()
		{
	//Remove The Product
	     Reporter.log("Product removing Started Successfully",true);
	
	      driver.findElement(By.tagName("a")).click();
	
	      Reporter.log("Product removed Successfully",true);
	      WebElement confirm_msg = driver.findElement(By.xpath("//b[normalize-space()='Your cart is empty.']"));
			
			if(confirm_msg.isDisplayed())
			{
				Reporter.log("Your cart is empty.", true);
				test.pass("Your cart is empty..");
			}
			else
			{
				Reporter.log("Your cart is not empty.", true);
				test.fail("Your cart is not empty.");
			}
		}
  
}
