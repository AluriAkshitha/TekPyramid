package ProductTest;

public class FishProduct {

}
