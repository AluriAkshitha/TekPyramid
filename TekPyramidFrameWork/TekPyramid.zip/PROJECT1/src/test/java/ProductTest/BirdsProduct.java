package ProductTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class BirdsProduct {
	WebDriver driver;
  @Parameters("BowserName")
	
	@BeforeClass
	public void browserSetup()
	{
//		String browser="chrome";
	Reporter.log("Browser Launched Successful",true);
		
	}
	
	@BeforeMethod
	public void signIn()
	{
		Reporter.log("SignIn Done Successful",true);
	}
	
	@AfterMethod
	public void signOut()
	{
		Reporter.log("SignOut Done Successful",true);	
	}
	
	@AfterClass
	public void browserTerminate()
	{
		driver.close();
	
		Reporter.log("Browser Terminated Successful",true);	
	}
	
	
	@Test
	public void addFirstProduct()
	{
		//Wait Statement
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	Reporter.log("Bird Product Test-Amazon Parrot",true);	
	}
	
	public void removeFirstProductVerify()
	{
		
	}
	

}
