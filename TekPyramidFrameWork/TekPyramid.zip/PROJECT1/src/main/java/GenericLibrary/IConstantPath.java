package GenericLibrary;

public interface IConstantPath {

}
