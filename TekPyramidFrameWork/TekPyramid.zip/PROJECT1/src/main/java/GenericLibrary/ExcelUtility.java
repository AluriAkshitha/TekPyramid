package GenericLibrary;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelUtility {
	/**
	 * This Class contains Reusable Method To Read And Write The Data To The Excel File
	 * @author Kallem Akshitha
	 */


		private Workbook wb; // encapsulate with same class
		private DataFormatter df;
		private FileInputStream fis;
		private FileOutputStream fos;
		
		/**
		 * This Method initializes excel file
		 * @param excelPath
		 */
		public void excelinit(String excelPath) 
		{
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(excelPath);
			}
			catch(FileNotFoundException e) {
				e.printStackTrace();
			}
			try 
			{
				wb = WorkbookFactory.create(fis);
			}
			catch (IOException e) {
				e.printStackTrace();
			}
			df = new DataFormatter();
		}
		
		/** 
		 * This Method is used to close workbook
		 */
		public void closeExcel()
		{
			try {
				wb.close();
			}catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		
		/**
		 * This Method is used to update test status
		 * 
		 * @param sheetName
		 * @param expectedTestName
		 * @param status
		 * @param excelPath
		 */
		public void setTestStatus(String sheetName, String status, String excelPath, int row, int cell) {
			
			// update test status in excel
			wb.getSheet(sheetName).getRow(row).createCell(cell).setCellValue(status);
			
			// convert java readable file into physical file 
			try {
				fos = new FileOutputStream(excelPath);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			// write the data
			try {
				wb.write(fos);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		/**
		 * 
		 * This Method used to read the data from excel
		 * 
		 * 
		 * 
		 * @param SheetName
		 * @param Row Number
		 * @param Column/Cell Number
		 * @return Expected Data
		 */
		
		public String readSingleData(String sheetname, int row, int cell)
		{
			String data = wb.getSheet(sheetname).getRow(0).getCell(0).getStringCellValue();
			return data;
			
		}
		
		public  void readMultipleData(String Sheetname, int row)
		{
			int rowcount = wb.getSheet(Sheetname).getLastRowNum();
			for(int i = 1; i< rowcount; i++)
			{
				String data1 = wb.getSheet("Sheetname").getRow(i).getCell(1).getStringCellValue();
				String data2 = wb.getSheet("Sheetname").getRow(i).getCell(2).getStringCellValue();
			}	
		}

}
