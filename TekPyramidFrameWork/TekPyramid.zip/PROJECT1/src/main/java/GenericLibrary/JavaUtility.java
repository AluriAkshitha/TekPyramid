package GenericLibrary;

public class JavaUtility {

}
