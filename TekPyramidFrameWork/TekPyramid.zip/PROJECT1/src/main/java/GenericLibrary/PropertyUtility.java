package GenericLibrary;

public class PropertyUtility {

}
