package com.DomsEpson.ProductTest;

import org.testng.annotations.Test;

public class ElectronicProductTest {
	
	@Test
	public void addProduct()
	{
	System.out.println("Add Product Successfully-ELECTRONICS-");	
	
	}
	
	@Test
	public void updateProduct()
	{
		System.out.println("Update the Product Successfully-ELECTRONICS-");

	}
	@Test
	public void removeProduct()
	{
		System.out.println("Remove Product Successfully-ELECTRONICS-");
		
	}

}
