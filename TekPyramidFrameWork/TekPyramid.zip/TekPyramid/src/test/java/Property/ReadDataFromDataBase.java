package Property;


import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.Driver;

public class ReadDataFromDataBase {

	public static void main(String[] args) throws SQLException  {
		// TODO Auto-generated method stub
		Driver driverRef = new Driver();
		DriverManager.registerDriver(driverRef);
		Connection conn = DriverManager.getConnection("jdbc:mysql:106.51.90.215:3333/projects", "root@%", "root");
		System.out.println("=========done========");
		Statement stat = conn.createStatement();
//		ResultSet set = stat.executeQuery("select * from project");
//		while (set.next()) {
//			String actFirstName=set.getString(4);
//			if(projectname.equalsIgnoreCase(actFirstName)) {
//				flag=true;
//				System.out.println(projectname+" is available==pass");
//			}
//			} 
//		if(flag==false) {
//			System.out.println(projectname+" is not available==fail");
//		}
		conn.close();
	}

}
