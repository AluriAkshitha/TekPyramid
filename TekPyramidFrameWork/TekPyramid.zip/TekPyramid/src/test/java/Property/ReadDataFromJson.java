package Property;

import java.io.FileInputStream;
import java.io.FileReader;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ReadDataFromJson {
	
	@Test
	public void Login() throws Throwable
	{
		//Reading Common Data From JSON file
		//Converting json physical file into Java object
		JSONParser parser=new JSONParser();
		Object obj=parser.parse(new FileReader("C:\\Users\\Kallem Akshitha\\OneDrive\\Desktop\\Tekpyramid\\Data.json"));
		JSONObject map=(JSONObject)obj;
		 
		 
		String URL=map.get("url").toString();
		String BROWSER=map.get("browser").toString();
		
		String UN=map.get("username").toString();
		String PWD=map.get("password").toString();
		
		FileInputStream fis1=new FileInputStream("C:\\Users\\Kallem Akshitha\\OneDrive\\Desktop\\Tekpyramid\\Tekpyramid.xlsx");
		Workbook wb=WorkbookFactory.create(fis1);
		Sheet s=wb.getSheet("Sheet1");
		Row row=s.getRow(1);
		String Productname=row.getCell(0).toString();
		wb.close();
		
		
		WebDriver driver=null;
		if(BROWSER.equals("chrome"))
		{
			 WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
		}
		else if(BROWSER.equals("firefox"))
		{
			 WebDriverManager.firefoxdriver().setup();
			driver=new FirefoxDriver();
		}
		else if(BROWSER.equals("edge"))
		{
			 WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
		}
		else
		{
			 WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
		}
		
		//Login to the application
		driver.get(URL);
		driver.findElement(By.className("ico-login")).click();
		driver.findElement(By.id("Email")).sendKeys(UN);
		driver.findElement(By.id("Password")).sendKeys(PWD);
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();

}
}
