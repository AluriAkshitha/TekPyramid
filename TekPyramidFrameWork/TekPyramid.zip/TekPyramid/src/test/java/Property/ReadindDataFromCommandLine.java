package Property;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ReadindDataFromCommandLine {
	
	@Test
	public void Login() throws Throwable
	{
		//Reading Common Data From CommandLine
		String URL=System.getProperty("url");
		String BROWSER=System.getProperty("browser");
		String UN=System.getProperty("username");
		String PWD=System.getProperty("password");
		
		FileInputStream fis1=new FileInputStream("C:\\Users\\Kallem Akshitha\\OneDrive\\Desktop\\Tekpyramid\\Tekpyramid.xlsx");
		Workbook wb=WorkbookFactory.create(fis1);
		Sheet s=wb.getSheet("Sheet1");
		Row row=s.getRow(1);
		String Productname=row.getCell(0).toString();
		wb.close();
		
		
		WebDriver driver=null;
		if(BROWSER.equals("chrome"))
		{
			 WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
		}
		else if(BROWSER.equals("firefox"))
		{
			 WebDriverManager.firefoxdriver().setup();
			driver=new FirefoxDriver();
		}
		else if(BROWSER.equals("edge"))
		{
			 WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
		}
		else
		{
			 WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
		}
		
		//Login to the application
		driver.get(URL);
		driver.findElement(By.className("ico-login")).click();
		driver.findElement(By.id("Email")).sendKeys(UN);
		driver.findElement(By.id("Password")).sendKeys(PWD);
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();
		driver.findElement(By.partialLinkText("Books")).click();
		driver.findElement(By.id("small-searchterms")).sendKeys(Productname);
		
		
	}

}
