package Property;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Proper {

	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub
		
		FileInputStream fis=new FileInputStream("C:\\Users\\Kallem Akshitha\\OneDrive\\Desktop\\CommonData.Properties");
		Properties pr=new Properties();
		pr.load(fis);
		
		String Browser=pr.getProperty("browser");
		String Url=pr.getProperty("url");
		String Un=pr.getProperty("username");
		String Pwd=pr.getProperty("password");
		
		WebDriver driver=null;
		if(Browser.equals("chrome"))
		{
			 WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
		}
		else if(Browser.equals("firefox"))
		{
			 WebDriverManager.firefoxdriver().setup();
			driver=new FirefoxDriver();
		}
		else if(Browser.equals("edge"))
		{
			 WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
		}
		else
		{
			 WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
		}
		
		//Login to the application
		driver.get(Url);
		driver.findElement(By.className("ico-login")).click();
		driver.findElement(By.id("Email")).sendKeys(Un);
		driver.findElement(By.id("Password")).sendKeys(Pwd);
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();
		
		

	}

	
}
