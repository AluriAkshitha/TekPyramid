package Property;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ReadMultipleData {

	public static void main(String[] args) throws Throwable {
		FileInputStream fis=new FileInputStream("C:\\Users\\Kallem Akshitha\\OneDrive\\Desktop\\Tekpyramid.xlsx");
		Workbook wb=WorkbookFactory.create(fis);
		Sheet s=wb.getSheet("Sheet2");
		int rowcount=s.getLastRowNum();
		for(int i=1;i<=rowcount;i++)
		{
			Row row = s.getRow(i);
			String column1=row.getCell(0).toString();
			String column2=row.getCell(1).toString();
			
			System.out.println(column1+" "+column2);
			
		}
		wb.close();

	}

}
